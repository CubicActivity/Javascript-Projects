//document.getElementById("counter").innerText = 5

// change the counter in the HTML to reflect the new count

let saveEl = document.getElementById("save-el")
let counter = document.getElementById("counter")
let count = 0

function save() {
    let entry = count + " - "
    saveEl.textContent += entry
    count = 0;
    counter.innerText = 0
    console.log(count)
}

function increment() {
    count += 1
    console.log(count)
    counter.innerText = count
}

function decrement() {
    if (count > 0) {
        count -= 1
        console.log(count)
        counter.innerText = count
    }
}
