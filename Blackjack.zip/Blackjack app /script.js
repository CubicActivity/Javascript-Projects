let cards = []
let sum = 0
let hasBlackJack = false
let isAlive = false
let message = ""
let messageEl = document.getElementById("message-el")
let sumEl = document.querySelector("#sum-el")
let cardsEl = document.querySelector("#cards-el")
let playerEl = document.querySelector("#player-el")

let player = {
    playerName: "Angel",
    playerChips: 145
}

function getRandomCard() {
    //Random card number between 1 and 13
    let card = Math.floor(Math.random() * 13) + 1

    //Sets the value of the cards based on number
    if (card == 1) {
        return 11
    } else if (card == 11 || card == 12 || card == 13) {
        return 10
    } else return card
}

function startGame() {
    //Checks if a game is running before starting a new one
    if (!isAlive) {
        cards = []
        sum = 0
        isAlive = true
        let firstCard = getRandomCard()
        let secondCard = getRandomCard()
        sum += firstCard + secondCard
        cards.push(firstCard, secondCard)
        console.log(cards)
        renderGame()
    }

}

function renderGame() {

    //Renders chips
    renderChips()


    //Renders sum
    renderSum()

    //Renders cards
    renderCards()

    //Checks for blackjack conditions
    renderBlackjack()

    //Renders message from blackjack function
    renderMessage()


}
//Adds a new card to the deck and runs renderGame()
function newCard() {
    if (isAlive && !hasBlackJack) {
        let newCard = getRandomCard()
        cards.push(newCard)
        sum += newCard
        console.log(cards)
        renderGame()
    }

}
// Function Called when you win blackjack in renderBlackjack() 
function blackJack() {
    if (hasBlackJack) {
        isAlive = false
        player.playerChips += 2000
        renderChips()
        hasBlackJack = false
    }

}
// Renders the player chips
function renderChips() {
    playerEl.textContent = player.playerName + ": $" + player.playerChips
}
// Renders the sum of the cards
function renderSum() {
    sumEl.textContent = "Sum: " + sum
}

function renderBlackjack() {
    if (sum <= 20) {
        message = "Do you want to draw a new card?"
    } else if (sum === 21) {
        message = "Woohoo! You've got Blackjack!"
        hasBlackJack = true
        blackJack()
    } else {
        message = "You're out of the game!"
        isAlive = false
        player.playerChips -= 20
        renderChips()
    }
}
// Renders message set at renderBlackjack function
function renderMessage() {
    messageEl.textContent = message
}
// Renders cards in the deck
function renderCards() {
    cardsEl.textContent = "Cards: "
    for (let i = 0; i < cards.length; i++) {
        cardsEl.textContent += cards[i] + " "
    }
}